/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.me.FlightBooking;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;


/**
 * REST Web Service
 *
 * @author Dominique
 */
@Path("getdirectionsrestWS")
public class GetDirectionsRestWS {

    @Context
    private UriInfo context;

    /**
     * Creates a new instance of GetDirectionsRestWS
     */
    public GetDirectionsRestWS() {
    }

    /**
     * Retrieves representation of an instance of org.me.FlightBooking.GetDirectionsRestWS
     * @return an instance of java.lang.String
     */
//    @GET
//    @Produces(MediaType.TEXT_HTML)
//    public String getHtml() {
//        //TODO return proper representation object
//       // throw new UnsupportedOperationException();
//    }
       
       @GET
@Produces("text/html")
public String getHtml(@QueryParam("originPostCode")String originPostCode, @QueryParam("destinationPostCode")String destinationPostCode ){
    //  public String returnDirections(@WebParam(name = "originPostCode") String originPostCode, @WebParam(name = "destinationPostCode") String destinationPostCode) {
    //original way;
    //public String getHtml() {
    //return "<html><body><h1>Hello, from RESTful Web Service!!</body></h1></html>";
        
        String composedURL="https://maps.googleapis.com/maps/api/directions/json?origin=NG16HY&mode=walking&destination=NG35QJ&key=AIzaSyADZRONKow2HZwxNl_CBMJSpFbpebHV4eY";  
       StringBuilder sb = new StringBuilder();
       try {
            //setup URL connection for HTTP GET
         
                URL url = new URL(composedURL);
                HttpURLConnection connURL = (HttpURLConnection) url.openConnection();
                connURL.setRequestMethod("GET");
                connURL.connect();
                //read response direcgly into a String buffer
                BufferedReader ins = new BufferedReader(new InputStreamReader(connURL.getInputStream()));
                String inString;
                
                
                    while ((inString = ins.readLine()) != null) {
                        sb.append(inString);
                        //add carriage return for clarity (not required for parsing)
                        //sb.append("\n");
                    }
           
                //make sure you close the stream and the connection
                ins.close();
                connURL.disconnect();
                
                }
            
            
                    catch (MalformedURLException me) {
                    System.out.println("MalformedURLException: " + me);
                    }
                    catch (IOException ioe) {
                    System.out.println("IOException: " + ioe);
                    }
       
      
        //return sb.toString();
        return "bobbins";
    }

    /**
     * PUT method for updating or creating an instance of GetDirectionsRestWS
     * @param content representation for the resource
     */
    @PUT
    @Consumes(MediaType.TEXT_HTML)
    public void putHtml(String content) {
    }
}
