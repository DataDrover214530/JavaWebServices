/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.me.FlightBooking;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.TimeZone;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;



/**
 *
 * @author Dominique
 */
@WebService(serviceName = "GetDirectionsWS")
public class GetDirectionsWS {


    /**
     * Web service operation
     */
    @WebMethod(operationName = "returnDirections")
    public List<String> returnDirections(@WebParam(name = "originPostCode") String originPostCode, @WebParam(name = "destinationPostCode") String destinationPostCode, String mode) throws ParseException, ProtocolException, IOException {
       //parts that will form the URL request to Google Directions
       final String API_KEY = "&key=AIzaSyADZRONKow2HZwxNl_CBMJSpFbpebHV4eY";
       final String GOOGLE_PREAMBLE = "https://maps.googleapis.com/maps/api/directions/json?";
       //TODO could also add option parameters for for units, avoid etc.
       final String UNITS = "&units=imperial";  //I prefer the results in miles
       //final String GOOGLE_MODE = "&mode=driving";
       String GOOGLE_MODE="";
       String origin = "&origin=" + originPostCode;
       String destination = "&destination=" + destinationPostCode;
        if (mode.equals("transit")){
           GOOGLE_MODE =  "&mode=transit";
           }
            else if (mode.equals("driving")){
               GOOGLE_MODE =  "&mode=driving";
               }
                else{//failsafe to driving
                  GOOGLE_MODE =  "&mode=driving";  
                }
       String composedURL= GOOGLE_PREAMBLE + origin + UNITS + GOOGLE_MODE + destination + API_KEY;
       
       StringBuilder sb = new StringBuilder();
       try {
            //setup URL connection for HTTP GET
         
                URL url = new URL(composedURL);
                HttpURLConnection connURL = (HttpURLConnection) url.openConnection();
                connURL.setRequestMethod("GET");
                connURL.connect();
                //read response direcgly into a String buffer
                BufferedReader ins = new BufferedReader(new InputStreamReader(connURL.getInputStream()));
                String inString;
                
                
                    while ((inString = ins.readLine()) != null) {
                        sb.append(inString);
                        //add carriage return for clarity (not required for parsing)
                        sb.append("\n");
                    }
                         
                //make sure you close the stream and the connection
                ins.close();
                connURL.disconnect();
                
                }
            
            
                    catch (MalformedURLException me) {
                    System.out.println("MalformedURLException: " + me);
                    }
                    catch (IOException ioe) {
                    System.out.println("IOException: " + ioe);
                    }
       
String JSONstring = sb.toString();       
//using the org.json.simple parser to decompose the JSON response
//and strip out the parts we need. We need to run down the document
//tree step by step, extracting the object of interest and then 
//extracting the sub-parts until we get to the values we want. 
JSONParser parser = new JSONParser();
Object myObj = parser.parse(JSONstring);
JSONObject theData = (JSONObject) myObj;

//the JSON response contains a bunch of objects with nested data within
//the parts we are interested in are formed as
//routes > 0 > legs > steps... iterate through the steps
//and extract distance.text[data] and html_instructions [data]
//so we need to take the JSON response and drill down through the
//objects until we get to the part we are interested in, then iterate
//through extracting the data from the onbjects and their arrays of data
//the below code adapted from https://stackoverflow.com/questions/25360231/parse-json-array-from-google-maps-api-in-java
JSONArray subObject1 = (JSONArray) theData.get("routes");
JSONObject subObject2 = (JSONObject)subObject1.get(0);
JSONArray subObject3 = (JSONArray)subObject2.get("legs");
JSONObject subObject4 = (JSONObject)subObject3.get(0);
//here we go, the data we are interested in;
JSONArray steps = (JSONArray) subObject4.get("steps");



String directionString="";  
String latString="";
String lngString="";
List<String> directions = new ArrayList<String>();  



//directions.add(lat);
//directions.add(lng);
//steps contains a number of Objects that we can now drill into to 
//extract the exact data we need - the directions (html_instructions)
//and the text description of the distance which itself is held in as
//and entry in the sub-array "distance"
for(Object obj: steps){
    if ( obj instanceof JSONObject ) {

        //grab the html_instructions, it is a single field
        //System.out.println(((JSONObject) obj).get("html_instructions"));
        //slighty more complext - grab the text part of the distance sub-array
        //by extracting it as a sub-object and accessing the element at key "text"
        Object distance = ((JSONObject) obj).get("distance");
        //concatenate the values together so that they make sense as a string
        directionString = ((JSONObject) obj).get("html_instructions") + " [" + ((JSONObject) distance).get("text") + "]"; 
        directions.add(directionString);
       
    }
}
  
//now we will call the function which calles the Geonames Timezone service to get the
//timezone of the destination. QoS: even though this is not strictly a part of the
//directions we will send this over in the directions array to save sending more costly traffic

        Object loc = ((JSONObject) subObject4).get("end_location");
        latString = ((JSONObject) loc).get("lat") + ""; 
        lngString = ((JSONObject) loc).get("lng") + ""; 
        
        String timezone = getTimezone(latString,lngString);
        
        TimeZone tz = TimeZone.getTimeZone(timezone);
        directions.add(tz.getDisplayName());
       
//note this function will try to get  directions but if that is not possible (i.e. locations
//in different landmasses) then the results will be a well formed but empty object. This will throw
//a SOAP exception, which the client will catch and deal with
        return directions;
      
    }
    
    //------------------------------------------------------------------------------------------

  public String getTimezone(String lat, String lng) throws ProtocolException, IOException{
  //TODO error handling in this function. At the moment it could return garbage
  //non-gracefully if the Geonames service is down or provides a non-well-formed response
      
       final String urlString = "http://api.geonames.org/timezone";
       final String urlParams = "?lat=" + lat + "&lng=" + lng + "&username=cc214530";
       String returnString = "";
         
       try {
            //setup URL connection for HTTP GET
            final String composedURL = urlString+urlParams;
                URL url = new URL(composedURL);
                HttpURLConnection connURL = (HttpURLConnection) url.openConnection();
                connURL.setRequestMethod("GET");
                connURL.connect();
                //read response direcgly into a String buffer
                BufferedReader ins = new BufferedReader(new InputStreamReader(connURL.getInputStream()));
                String inString;
                StringBuilder sb = new StringBuilder();
                
                    while ((inString = ins.readLine()) != null) {
/*this is a bit nasty! Instead of working through the response from the Geonames service which comes in the form;
 <geonames>
 <timezone tzversion="tzdata2017c">
<countryCode>GB</countryCode> ...etc
 I am just text-stripping out the part I need. I want the text timezone whic I can then convert to the timezone code
*/    
                        if (inString.contains("<timezoneId>")){
                        sb.append(inString);
                        }

                    }
                         
                //make sure you close the stream and the connection
                ins.close();
                connURL.disconnect();
                returnString = sb.toString();
                }
                           catch (MalformedURLException me) {
                    System.out.println("MalformedURLException: " + me);
                    }
    return returnString;   
   }
}

