/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.me.FlightBooking;

import flightRetrieval.*;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.Iterator;
import java.util.List;
import javax.jws.WebService;
import javax.ejb.Stateless;
import javax.ws.rs.GET;
import static javax.ws.rs.HttpMethod.GET;
import javax.ws.rs.core.MediaType;
import javax.xml.bind.JAXBException;
import javax.xml.bind.*;



/**
 *
 * @author Dominique
 */
@WebService(serviceName = "ReturnFlightsList")
@Stateless()
public class ReturnFlightsList {
    
    public List<FlightType> listFlights(String origin, String destination, String airline, int available_seats, 
            int connections, float fareValue, String userCurrency) throws JAXBException, IOException{
//the list I will read from the XML data, populated  from the xml
ListOfFlights myList = new ListOfFlights(); 
//the list I will fill with my first batch of unrefined matches
ListOfFlights workingList = new ListOfFlights(); 
//the list I will fill with any matched data to send back
ListOfFlights returnList = new ListOfFlights(); 

//setting up the list for unfiltered matches ready to fill with matching flights
//List<FlightType> theWorking = returnList.getFlightDetails();
List<FlightType> theWorking = workingList.getFlightDetails();

//setting up the actual list to go back, ready to fill with matching flights
List<FlightType> theReturn = returnList.getFlightDetails();

//setting up the list of all flights available by calling the function
//that reads the flight data in from the file and using what it
//returns to populate the objects. 
List<FlightType> UnMarshalledFlights = readInFromFile(myList).getFlightDetails();


//So now we have a list of all available flights and we have whatever
//flight details the user wanted to specify. We use them to search and 
//save any matching flights to the list.  
Iterator itr = UnMarshalledFlights.iterator();
    while(itr.hasNext()) {
        FlightType nextFlight = new FlightType();
        nextFlight = (FlightType) itr.next();
         FlightType theFlight;
         theFlight = new FlightType();
            //first check the origin, destination and number of seats
            //Design Decision - airline, connections and price may be negotiable but origin, destination and seat availablity is not
            
            if ((nextFlight.getOriginCity().toLowerCase().equals(origin) || "".equals(origin))&&
                    (nextFlight.getDestinationCity().toLowerCase().equals(destination) || "".equals(destination))&&
                         (nextFlight.getAvailableSeats()>= available_seats)){   
                        //so either the origin and destinations match the user input and there are enough seats on the flight
                        //or in some or all cases the user hasn't specified a preference this will match
                        theFlight.setFlightNumber(nextFlight.getFlightNumber());
                        theFlight.setOriginCity(nextFlight.getOriginCity());
                        theFlight.setDestinationCity(nextFlight.getDestinationCity());
                        theFlight.setAirline(nextFlight.getAirline());
                        theFlight.setAvailableSeats(nextFlight.getAvailableSeats());
                        theFlight.setNumberOfConnections(nextFlight.getNumberOfConnections());
                        //get the complex type objects for fare and airport details
                        theFlight.setFare(nextFlight.getFare());
                        theFlight.setAirportAddress(nextFlight.getAirportAddress());
                        //add the flight to the list we are to return
                       theWorking.add(theFlight);
                       }
    }        
//now we want to take our working list and, if neccesary, filter it against the rest of the criteria
//remaining criteria are airline, connections and cost. 
if(airline==null & connections==0 & fareValue==0){
    //if all these are null then don't bother matching just send what we have back   
    theReturn = theWorking;
   }else{//we do have something to check
       Iterator itr2 = theWorking.iterator();
       while(itr2.hasNext()) {
                FlightType nextFlight2 = new FlightType();
                nextFlight2 = (FlightType) itr2.next();
                 FlightType theFlight2;
                 theFlight2 = new FlightType();
                 //first check the origin, destination and number of seats
                 //Design Decision - airline, connections and price may be negotiable but origin, destination and seat availablity is not

                    //for ease, grab the nextflight values out into variables
                    String thisAirline = nextFlight2.getAirline().toLowerCase();
                    int thisConns = nextFlight2.getNumberOfConnections();
                    float thisPrice = nextFlight2.getFare().getValue();

                    //for all intents and purposes a user input of NULL matches all,
                    //so let's encode that here to save checking against NULLs any further
                    if (airline==null){airline=thisAirline;}
                    if (connections==0){connections=thisConns;}
                    if (fareValue==0){fareValue=thisPrice;}

                            if (airline.equals(thisAirline) & connections == thisConns & fareValue==thisPrice){
                                        theReturn.add(theFlight2);
                            }
            }
    }   

                        //final check. If we did match some flights in the first place (origin, destination, seats) but 
                        //then failed to match against further criteria, we will send back the rough matches anyway
                        Iterator itr3 = theReturn.iterator();
                        if (!itr3.hasNext()){
                            theReturn = theWorking;
                        }

        return theReturn;
        
    }
//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//utility functions for reading in and out of xml files / POJOs  
//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
private ListOfFlights readInFromFile(ListOfFlights listofflights) throws JAXBException, FileNotFoundException, IOException {

    
 try {
//grabbing the data from the XML file that holds the flights
javax.xml.bind.JAXBContext jaxbCtx = javax.xml.bind.JAXBContext.newInstance(listofflights.getClass().getPackage().getName());
javax.xml.bind.Unmarshaller unmarshaller = jaxbCtx.createUnmarshaller();


//listofflights = (ListOfFlights) unmarshaller.unmarshal(new java.io.File("H:\\SCC\\Coursework\\FlightBookingService\\List_Of_Flights.xml")); //NOI18N
listofflights = (ListOfFlights) unmarshaller.unmarshal(new java.io.File("C:\\Users\\Flombot\\Documents\\University\\ServiceCloud\\Coursework\\FlightBookingService\\List_Of_Flights.xml")); //NOI18N             
//listofflights = (ListOfFlights) unmarshaller.unmarshal(new java.io.File("C:\\Users\\Michelle\\Documents\\NetBeansProjects\\FlightBookingService\\List_Of_Flights.xml")); //NOI18N 
///Warning - Absolute Filepath here



      } catch (javax.xml.bind.JAXBException ex) {
                java.util.logging.Logger.getLogger("global").log(java.util.logging.Level.SEVERE, null, ex); //NOI18N
                System.out.println("Error occured" + ex);

      }
return listofflights;
}
//---------------------------------------------------------------------------------------------------------------------------------
public void recordFlightBooking(String flightNum, int seatsToBook) throws JAXBException, FileNotFoundException, IOException {
  //Takes a flight number and a number of seats as an input so that the XML can be updated
  //starts by reading the current flight data from the XML so that it is completely up to date
  //make the necessary amendments to seats available and then saves the data back out so the XML is
  //updated ready for the next query / client 

ListOfFlights tmpList = new ListOfFlights();  
 try {
//grabbing the data from the XML file that holds the flights
javax.xml.bind.JAXBContext jaxbCtx = javax.xml.bind.JAXBContext.newInstance(tmpList.getClass().getPackage().getName());
javax.xml.bind.Unmarshaller unmarshaller = jaxbCtx.createUnmarshaller();

//tmpList = (ListOfFlights) unmarshaller.unmarshal(new java.io.File("H:\\SCC\\Coursework\\FlightBookingService\\List_Of_Flights.xml")); //NOI18N
tmpList = (ListOfFlights) unmarshaller.unmarshal(new java.io.File("C:\\Users\\Flombot\\Documents\\University\\ServiceCloud\\Coursework\\FlightBookingService\\List_Of_Flights.xml")); //NOI18N     
//tmpList = (ListOfFlights) unmarshaller.unmarshal(new java.io.File("C:\\Users\\Michelle\\Documents\\NetBeansProjects\\FlightBookingService\\List_Of_Flights.xml")); //NOI18N             
//Warning - Absolute Filepath here 

//to hold the flight objects...
List<FlightType> working = tmpList.getFlightDetails();
////---- 
Iterator itr1 = working.iterator();

                    while(itr1.hasNext()) {
                        FlightType nextFlight = new FlightType();
                        nextFlight = (FlightType) itr1.next();
                 
                        if (nextFlight.getFlightNumber().equals(flightNum))
                        {//should never be called if there aren't enough seats but check anyway
                            if (seatsToBook <= nextFlight.getAvailableSeats()){
                                 nextFlight.setAvailableSeats(nextFlight.getAvailableSeats()-seatsToBook);
                            }
                           //TODO: else error handler
                        }
                       
                    }

        Marshaller marshaller = jaxbCtx.createMarshaller();
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
    

            OutputStream os = new FileOutputStream( "C:\\Users\\Flombot\\Documents\\University\\ServiceCloud\\Coursework\\FlightBookingService\\List_Of_Flights.xml" );
            marshaller.marshal( tmpList, os );
            os.close();

      } catch (javax.xml.bind.JAXBException ex) {
                java.util.logging.Logger.getLogger("global").log(java.util.logging.Level.SEVERE, null, ex); //NOI18N
                System.out.println("Error occured" + ex);

      }

}



}