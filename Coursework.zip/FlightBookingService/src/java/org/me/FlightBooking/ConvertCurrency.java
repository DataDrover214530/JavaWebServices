/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.me.FlightBooking;

import java.util.ArrayList;
import java.util.List;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.ejb.Stateless;
import javax.xml.ws.WebServiceRef;
import modulewebservices.CurrencyConversionWSService;

/**
 *
 * @author Dominique
 */


@WebService(serviceName = "ConvertCurrency")
@Stateless()
public class ConvertCurrency {
    //importing the services from CurrencyConverter so we can use them
    @WebServiceRef(wsdlLocation = "WEB-INF/wsdl/localhost_8080/CurrencyConvertor/CurrencyConversionWSService.wsdl")
    private CurrencyConversionWSService service;

@WebMethod(operationName = "CurrencyRate")
public double CurrencyRate(@WebParam(name = "originCurr") String originCurr, @WebParam(name = "targetCurr") String targetCurr){
    
double rate = 0;

       // consuming the converstion rate web service
        // just a toy example to prove it works
        String from = originCurr;
        String to = targetCurr;
        rate = getConversionRate(from, to);
        
    
return rate;
}

@WebMethod(operationName = "CurrencyCodes")
public List<String> CurrencyCodes(){
    List<String> theCodes = new ArrayList();
    theCodes= getCurrencyCodes();
    return theCodes;
}

//call to a new method I added to the currency converter service 
//as I just wanted to return the codes without the country names
@WebMethod(operationName = "CurrencyCodesISO")
public List<String> CurrencyCodesISO(){
    List<String> theCodesISO = new ArrayList();
    theCodesISO= getCurrencyCodesISO();
    return theCodesISO;
}
    private double getConversionRate(java.lang.String arg0, java.lang.String arg1) {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        modulewebservices.CurrencyConversionWS port = service.getCurrencyConversionWSPort();
        return port.getConversionRate(arg0, arg1);
    }

    private java.util.List<java.lang.String> getCurrencyCodes() {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        modulewebservices.CurrencyConversionWS port = service.getCurrencyConversionWSPort();
        return port.getCurrencyCodes();
    }

    private java.util.List<java.lang.String> getCurrencyCodesISO() {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        modulewebservices.CurrencyConversionWS port = service.getCurrencyConversionWSPort();
        return port.getCurrencyCodesISO();
    }
    
    
    
}

