/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package flightbookingclient;

import FlightsWS.*;
import FlightsWS.FlightType.*;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import javax.xml.bind.JAXBException;
import org.json.simple.parser.ParseException;
import org.me.flightbooking.ParseException_Exception;
import org.jsoup.Jsoup;
import java.text.DecimalFormat;
import java.util.ArrayList;
import org.jsoup.safety.Whitelist;

/**
 *
 * @author Dominique
 */
public class FlightBookingClient {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException, ParseException, ParseException_Exception, JAXBException, IOException_Exception, JAXBException_Exception, FileNotFoundException_Exception {
    //ask the user for input so we can return relevant results
    //we permit them to skip by hitting enter and this leaves the 
    //relevant entry as NULL, 0 or 1 by default, as appropriate

        String origin = null, destination = null, airline = null, prefCurr = null;
        int available_seats = 1, connections = 0, flightToBook = 0, seatsToBook =-1;
        float fareValue = 0;
        String tmpSeats = null, tmpConns = null, tmpValue=null, ctrlInput="", timezone = "";
        //to show prices in human readable format
        DecimalFormat priceFormat = new DecimalFormat(".##"); 
        Scanner scanner = new Scanner(System.in);
        //grabbibg the currency codes from the currency code web service
        //QoS: it is more efficient to do it just once, upon initilisation
        //as the data will not change so multiple calls would be wasteful. 
         List<String> currencyCodes = new ArrayList(); //compile warning - unchecked conversion
         currencyCodes = currencyCodesISO();

    System.out.print(".\n.\n.\n.\n.\n");
    System.out.println("**************** Welcome to FlightCheckMate ****************");
          
    while(!"n".equals(ctrlInput)) {//we want the main menu in a loop so we can book multiple flights
     //resets
        origin = null;
        destination = null; 
        airline = null; 
        prefCurr = null;
        available_seats = 1; 
        connections = 0;
        flightToBook = -1000; //nasty. see comments in user input section
        seatsToBook = -1000; //nasty. see comments in user input section
        fareValue = 0;
        tmpSeats = null;
        tmpConns = null;
        tmpValue=null;
        ctrlInput="";
        
//        String bob = getHtml();
//        System.out.println(bob);
//        
 
      System.out.println("************************************************************");
      System.out.println("To look for flights you can enter your search details here.\n*");
      System.out.println("To leave any option blank, just hit 'Enter' and we'll find the closest match: \n*");
      //read in the user input from the command prompt
      System.out.print("Please input the city you wish to fly from and hit 'Enter':  ");
      origin = scanner.nextLine().toLowerCase();
             
      System.out.print("Please input the city you wish to fly to and hit 'Enter':  ");
      destination = scanner.nextLine().toLowerCase();
       
      System.out.print("Please input your prefered airline and hit 'Enter':  ");
      airline = scanner.nextLine().toLowerCase();

      System.out.print("Please input the number of seats you require and hit 'Enter' You can leave this blank for a default value of 1:  ");
            tmpSeats = scanner.nextLine();
           if ("".equals(tmpSeats)){
               //do nothing, the default value of 1 is fine 
            }
             else{
                     available_seats =  Integer.parseInt(tmpSeats); 
             }
      
      System.out.print("Please input the maximum number of changes you will accept and hit 'Enter':  ");
           tmpConns = scanner.nextLine();
           if ("".equals(tmpConns)){
               //do nothing, the default value of 1 is fine 
            }
             else{
                     connections =  Integer.parseInt(tmpSeats); 
             }
      //DEE ERRORS HERE
      System.out.print("If you would like prices in your home currency please enter the three character currency code:  ");
    boolean MATCH = false;
    while(!MATCH){
            prefCurr =  scanner.nextLine().trim().toUpperCase();
            if (prefCurr.equals("")| prefCurr.equals("X"))
            {//don't bother checking
                MATCH = true;
            }
            else{
 
                        for (int i = 0; i < currencyCodes.size(); i++) {
                          
                               if(currencyCodes.get(i).equals(prefCurr)){
                                  
                                   MATCH = true;
                               }

                        }
            if (!MATCH){System.out.print("Sorry, that code is not recognised. Please enter it again or hit 'x' to skip :  ");}
    
            }
     }
      System.out.print("Please input the maximum price you will accept and hit 'Enter':  ");
        tmpValue = scanner.nextLine();
           if ("".equals(tmpValue)){
               //do nothing, the default value of 1 is fine 
            }
             else{
                     fareValue =  Float.parseFloat(tmpValue); 
             }

        System.out.println("Looking for flights now...");
        System.out.print(".\n..\n...\n....\n...................................\n");
        
        /*just for testing;
        origin = "London";
        destination = "Toronto";
        airline = "Air Canada";
        available_seats = 2;
        connections=1;
        fareValue =1000.00f;
        prefCurr  = "USD";    
        System.out.println("origin " + origin + " destination" + destination + " airline " + airline + " available_seats" + available_seats + 
        " connections " + connections + " fareValue " + fareValue + " prefCurr " + prefCurr);
        just for testing;*/
        
        List<FlightType> aReturned = listFlights(origin, destination, airline, available_seats, connections, fareValue, prefCurr);
        //here we have all the matching flights back, including seats available and various postcodes
         Iterator xitr = aReturned.iterator();
         if (xitr.hasNext())
         {
           FlightType xnextFlight = new FlightType();
           Fare xfare = new Fare();
           double xPrice = 0.0f;
           double xRate = 0.0d;
           String thisCurr = "";
           int counter = 0;
                while(xitr.hasNext()) {
                    xnextFlight = (FlightType) xitr.next();
                    xfare = xnextFlight.getFare();
                   
                        //work out any cost conversion, if it needs to be done
                        //if they have expressed no preference then use the currecny 
                        //thats in the file for each flight
                        if (prefCurr.equals("")||prefCurr.equals("X")){ 
                            thisCurr = xfare.getCurrency();
                        }
                        else{
                            thisCurr = prefCurr;
                        }
    
                        if (xfare.getCurrency().equals(thisCurr)){//no conversion needed
                            xPrice = xfare.getValue();
                            thisCurr = xfare.getCurrency();
                        }
                        else{//do the conversion
                            xRate = currencyRate(xfare.getCurrency(), thisCurr);
                            xPrice = xfare.getValue() * xRate;
                    }
 //DEE HERE check the return here for perfect match and output "matching flight" or "closest match?"                       
                        counter++;
                        System.out.println("Matching flight [" + counter + "] as Flight " + xnextFlight.getFlightNumber() + " from " + xnextFlight.getOriginCity() + " to " + xnextFlight.getDestinationCity() + " flying with " +
                                xnextFlight.getAirline() + " with " + xnextFlight.getNumberOfConnections() + " change(s) at a cost of " + priceFormat.format(xPrice) + " " + thisCurr);
                        
                        }
System.out.print("Please enter the number of the flight you would like to book | ");  
            //the below is the error handler for user flight choice which can break the system 
            //if not propely checked. It's not perfect - the system will be confused by the entry 
            //of a number the same as the "error" number. Hence the nasty hack of presetting to 
            //-1000, sorry! The same system is used for the number of seats. 
            //TODO: Refactor this to something less hacky. Possibly use a boolean to flag it, rather than a number?
            while(flightToBook ==-1000 ) {
            try {
            flightToBook = Integer.parseInt(scanner.nextLine());
            } catch (Exception e) {
                System.out.print("\nSorry, you must enter a number. Please enter the number of the flight you would like to book | "); 
                flightToBook=-1000;
                }
                ////ok we got a number at least, but is it a valid number?
                if (flightToBook > counter | flightToBook < 1 & flightToBook != -1000){
                        //handle negative input

                    System.out.print("\nSorry you have entered an invalid choice. Please enter the number (between 1 and " + counter  + ") of the flight you would like to book | ");   
                    flightToBook=-1000;
                    }

            }//we can leave the while once we have a valid flight number

                //to allow mapping to the position on the list which is zero-based
                int flightToBookIdx = flightToBook-1;
                //and now we can make our object based on the flight the user selected
                FlightType bookedFlight = new FlightType();
                bookedFlight = aReturned.get(flightToBookIdx);


            System.out.print("How many seats would you like to book? | ");



            while(seatsToBook ==-1000 ) {
            try {
            seatsToBook =  Integer.parseInt(scanner.nextLine());
            } catch (Exception e) {
                System.out.print("\nSorry, you must enter a number. Please enter the number of seats you want to book | "); 
                seatsToBook=-1000;
                }
                    if (seatsToBook < 1){
                        //no, we need a positive number!
                       System.out.print("\nSorry, the minimum number of seats you can book is 1. Please enter the number of seats you want to book  | "); 
                        seatsToBook=-1000;
                         }else if(seatsToBook > bookedFlight.getAvailableSeats()) {//finally check there are enough seats on the flight
                            System.out.println("Sorry, there are only " + bookedFlight.getAvailableSeats() + " seats available on that flight. Please make a new selection.");
                            seatsToBook=-1000;
                         }
             }//we can leave the while now that we have a valid, bookable number of seats
/*
QoS issue here - if we spend long enough in this loop our data will become out of date, because we are working on
and object which we queried from the service. This means other clients could be booking flights such that, once we 
have finished, the seats might no longer be there. So we would need some kind of time-out system. 
*/

                            System.out.println("Thanks! Booking " + seatsToBook + " seat(s) on flight " + bookedFlight.getFlightNumber() + " now...\n....\n.....");
                            try{
                            //now we have picked the flight lets ask Google for directions. If Google cannot supply the directions
                            //we will move gracefully onto the catch and the user will not be alarmed.                  
                            List<String> airportDirectionsDriving = returnDirections(bookedFlight.getAirportAddress().getOriginAirportPostcode(), 
                            bookedFlight.getAirportAddress().getDestinationAirportPostcode(), "driving");
                            
                            List<String> airportDirectionsTransit = returnDirections(bookedFlight.getAirportAddress().getOriginAirportPostcode(), 
                            bookedFlight.getAirportAddress().getDestinationAirportPostcode(), "transit");
      
                            timezone = airportDirectionsDriving.get(airportDirectionsDriving.size()-1);
                            /*QoS issue here. For my own convenience I made two calls to the GoogleAPI via the get directions service and returned
                            two JSON objects - this uses uneccesary bandwidth. I also need to do this anywa because I rolled the timezone call to
                            Geonames in with the call to the Google API - oops! TODO: I should refactor this so that the call is made after the 
                            user makes their choice or either driving or transit and then only return the one relevant object*/
                            System.out.println("************************************************************");
                            System.out.println("Your origin and destination are on the same landmass.");
                            System.out.println("Would you like to see driving or public transport options for your journey?");
                            System.out.print("\n\nHit 1 for driving directions, 2 for public transport directions or hit 'Enter' to go ahead and book your flight | ");
                            String transitChoice = scanner.nextLine();
                            
     
                            if (transitChoice.equals("1")){
                                //rubbing out the timezone, we already grabbed it so lets use this slot for formatting
                                airportDirectionsDriving.set(airportDirectionsDriving.size()-1, "* * * ");
                   
                                        for (int i = 0; i < airportDirectionsDriving.size(); i++) {
                                        String dirtyDirs = airportDirectionsDriving.get(i);
                                           
                                            if (i == airportDirectionsDriving.size()-2){//if this is the penultimate line in the array...
                                             //there is a slight output bug here where the newline gets removed between the last step of directions
                                             //and the "Destination" part. So just going to hack it here so it looks nicer
                                               String replaced = Jsoup.clean(dirtyDirs, Whitelist.none()).replace("Destination", " - Destination");
                                               System.out.println(replaced);
                                            }
                                            else
                                            {
                                        System.out.println(Jsoup.clean(dirtyDirs, Whitelist.none()));

                                            }

                                        }
                                        System.out.println("Would you like to book the flight anyway? y/n |");
                                        transitChoice = scanner.nextLine();  
                           
                            }else if (transitChoice.equals("2")){
                                                                //rubbing out the timezone, we already grabbed it so lets use this slot for formatting
                                airportDirectionsDriving.set(airportDirectionsDriving.size()-1, "* * * ");
                                        for (int i = 0; i < airportDirectionsTransit.size(); i++) {
                                        String dirtyDirs = airportDirectionsDriving.get(i);
                                            if (i == airportDirectionsTransit.size()-2){//if this is the penultimate line in the array...
                                             //there is a slight output bug here where the newline gets removed between the last step of directions
                                             //and the "Destination" part. So just going to hack it here so it looks nicer
                                               String replaced = Jsoup.clean(dirtyDirs, Whitelist.none()).replace("Destination", " - Destination");
                                               System.out.println(replaced);
                                            }
                                            else
                                            {
                                        System.out.println(Jsoup.clean(dirtyDirs, Whitelist.none()));
                                      
 
                                            }
                                        }
                                        System.out.println("Would you like to book the flight anyway? y/n |");
                                        transitChoice = scanner.nextLine();   
                            }
                            if (!transitChoice.equals("n")){//any other input just book it. TODO: error handle accidental input so that people don't book flights on a miskey!
                            //book the flight! The use of this variable is a bit dirty and needs refactoring
                            
                            recordFlightBooking(bookedFlight.getFlightNumber(), seatsToBook);
                            System.out.println("You have sucessfully booked " + seatsToBook + " seat(s) on flight "
                                    + bookedFlight.getFlightNumber() + " " + bookedFlight.getOriginCity() 
                                    + " to " + bookedFlight.getDestinationCity() +"\n\nThe timezone at your destination is " + timezone + ", don't forget to set your watch!");     
                                    System.out.println("\n ***** Thank you for using FlightCheckMate! *****");
                            }
                            
                            }catch (javax.xml.ws.soap.SOAPFaultException soapFaultException) {
                                //System.out.println("SOAP error: " + soapFaultException); //for debugging
                                //carry on...
                                   recordFlightBooking(bookedFlight.getFlightNumber(), seatsToBook);
                                    System.out.println("You have sucessfully booked " + seatsToBook + " seat(s) on flight "
                                    + bookedFlight.getFlightNumber() + " " + bookedFlight.getOriginCity() 
                                    + " to " + bookedFlight.getDestinationCity() +".\n ***** Thank you for using FlightCheckMate *****");   
                                }                              
      
                
                       
         }
         else
         {
            System.out.println("Sorry there are no matching flights for your search criteria"); 
         }  
//just for testing, proving that the currecy converter service works in full
//the important thing here is that the client does not know about
//the currency converter service. It gets currency functionality from
//the flightbooking service which in turn provides functionality from 
//the currency service. So the client does not need to know about the
//currency converter service at all. 
//just prove we can output the rate;
//System.out.println("The exhange rate between the UK and USA is = " + currencyRate("USD", "GBP"));
////just to prove we can output the codes
//            System.out.println("Currency Codes:");
//
//            List<String> cuurCodes = new ArrayList();
//            cuurCodes = currencyCodes();
//
//                  for (int i = 0; i < cuurCodes.size(); i++) {
//                          System.out.println(cuurCodes.get(i));
//                  }
        System.out.println("*\nWould you like to search for more flights? y/n : ");
        ctrlInput = scanner.nextLine().toLowerCase();
       
        }//end while   

      System.out.print("\n.\n.\n");
      System.out.println("*** Thanks for using FlightCheckMate. See you again soon! ***"); 
    }

//----------------------------------------------------------------------------------------------------------------------
    private static double currencyRate(java.lang.String originCurr, java.lang.String targetCurr) {
        flightbookingclient.ConvertCurrency_Service service = new flightbookingclient.ConvertCurrency_Service();
        flightbookingclient.ConvertCurrency port = service.getConvertCurrencyPort();
        return port.currencyRate(originCurr, targetCurr);
    }

    private static java.util.List<java.lang.String> currencyCodes() {
        flightbookingclient.ConvertCurrency_Service service = new flightbookingclient.ConvertCurrency_Service();
        flightbookingclient.ConvertCurrency port = service.getConvertCurrencyPort();
        return port.currencyCodes();
    }

   

    private static java.util.List<FlightsWS.FlightType> listFlights(java.lang.String arg0, java.lang.String arg1, java.lang.String arg2, int arg3, int arg4, float arg5, java.lang.String arg6) throws IOException_Exception, JAXBException_Exception {
        FlightsWS.ReturnFlightsList_Service service = new FlightsWS.ReturnFlightsList_Service();
        FlightsWS.ReturnFlightsList port = service.getReturnFlightsListPort();
        return port.listFlights(arg0, arg1, arg2, arg3, arg4, arg5, arg6);
    }


    private static void recordFlightBooking(java.lang.String arg0, int arg1) throws IOException_Exception, FileNotFoundException_Exception, JAXBException_Exception {
        FlightsWS.ReturnFlightsList_Service service = new FlightsWS.ReturnFlightsList_Service();
        FlightsWS.ReturnFlightsList port = service.getReturnFlightsListPort();
        port.recordFlightBooking(arg0, arg1);
    }

    private static java.util.List<java.lang.String> returnDirections(java.lang.String originPostCode, java.lang.String destinationPostCode, java.lang.String arg2) throws ParseException_Exception {
        org.me.flightbooking.GetDirectionsWS_Service service = new org.me.flightbooking.GetDirectionsWS_Service();
        org.me.flightbooking.GetDirectionsWS port = service.getGetDirectionsWSPort();
        return port.returnDirections(originPostCode, destinationPostCode, arg2);
    }

    private static java.util.List<java.lang.String> currencyCodesISO() {
        flightbookingclient.ConvertCurrency_Service service = new flightbookingclient.ConvertCurrency_Service();
        flightbookingclient.ConvertCurrency port = service.getConvertCurrencyPort();
        return port.currencyCodesISO();
    }

 


}
